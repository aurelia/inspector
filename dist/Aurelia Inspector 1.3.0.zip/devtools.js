chrome.devtools.panels.elements.createSidebarPane(
  "Aurelia",
  function(sidebar) {
    sidebar.setPage('index.html');
  }
);
